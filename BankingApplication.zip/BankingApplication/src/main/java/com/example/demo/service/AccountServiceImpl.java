package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Account;
import com.example.demo.repo.AccountRepository;
@Service

public class AccountServiceImpl  implements AccountService{

	@Autowired
	AccountRepository repo;
	
	@Override
	public Account createAccount(Account account) {
		Account account_saved = repo.save(account);
		return account_saved;
	}

	@Override
	public Account getAccountDetailsByAccountNumber(Long Account_num) {
		Optional<Account>account= repo.findById(Account_num);
		if(account.isEmpty()) {
			throw new RuntimeException("Account Does not exists");
		}
		Account account_found= account.get();
		return account_found;
	}

	@Override
	public List<Account> getAllAccountDetails() {
		List<Account>listofAccounts = repo.findAll();
		return listofAccounts;
	}

	@Override
	public Account depositingAmount(Long Account_num, Double amount) {
		Optional<Account> account = repo.findById(Account_num);
		if(account.isEmpty()) {
			throw new RuntimeException("Account not present");
		}
		Account account_pre = account.get();
		Double totalBalance = account_pre.getAccount_balance()+amount;
		account_pre.setAccount_balance(totalBalance);
		repo.save(account_pre);
		return account_pre;
	}

	@Override
	public Account withdrawAmount(Long Account_num, Double amount) {
		Optional<Account> account = repo.findById(Account_num);
		if(account.isEmpty()) {
			throw new RuntimeException("Account not present");
		}
		Account account_pre = account.get();
		Double account_bal = account_pre.getAccount_balance()-amount;
		account_pre.setAccount_balance(account_bal);
		repo.save(account_pre);
		return account_pre;
	}

	@Override
	public void closeAccount(Long Account_num) {
		getAccountDetailsByAccountNumber(Account_num);
		repo.deleteById(Account_num);
	}

}
