package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Account;

public interface AccountService {

	public Account createAccount(Account account);
	public Account getAccountDetailsByAccountNumber(Long Account_num);
	public List<Account>getAllAccountDetails();
	public Account depositingAmount(Long Account_num, Double amount);
	public Account withdrawAmount(Long Account_num, Double amount);
	public void closeAccount(Long Account_num);
}
