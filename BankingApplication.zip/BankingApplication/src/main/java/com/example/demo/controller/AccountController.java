package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Account;
import com.example.demo.service.AccountService;

@RestController
@RequestMapping("/account")
public class AccountController {
	
	@Autowired
	AccountService service;
	
	//Creating Account 
	@PostMapping("/create")
	public ResponseEntity<Account> createAccount(@RequestBody Account account) {
		Account createAccount= service.createAccount(account);
		return ResponseEntity.status(HttpStatus.CREATED).body(createAccount);		
	}
	
	@GetMapping("/{account_num}")
	public Account getAccountByAccout_Num(@PathVariable Long account_num) {
		Account account= service.getAccountDetailsByAccountNumber(account_num);
		return account;
	}
	@GetMapping("/getallaccounts")
	public List<Account>getAccountDetails(){
		 List<Account>allAccountDetails= service.getAllAccountDetails();
		return allAccountDetails;
	}
	@PutMapping("/deposit/{account_num}/{amount}")
	public Account depositAccount(@PathVariable Long account_num, @PathVariable Double amount) {
		Account account = service.depositingAmount(account_num, amount);
		return account;
	}
	@PutMapping("/withdraw/{account_num}/{amount}")
	public Account withdrawAmount(@PathVariable Long account_num, @PathVariable Double amount) {
		Account account = service.withdrawAmount(account_num, amount);
		return account;
	}
	@DeleteMapping("/delete/{acconut_num}")
	private ResponseEntity<String> deleteAccount(@PathVariable Long acconut_num) {
		service.closeAccount(acconut_num);
		return ResponseEntity.ok("Acccount_Closed");
	}
	
}
