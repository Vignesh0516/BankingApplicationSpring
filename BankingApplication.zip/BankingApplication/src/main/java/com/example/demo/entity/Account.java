package com.example.demo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table
public class Account {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long Account_num;
	@Column
	private String Acount_holder_name;
	@Column
	private Double Account_balance;
	
	public Account() {
	}
	
	public Account(String acount_holder_name, Double account_balance) {
		super();
		Acount_holder_name = acount_holder_name;
		Account_balance = account_balance;
	}

	public long getAccount_num() {
		return Account_num;
	}
	public void setAccount_num(long account_num) {
		Account_num = account_num;
	}
	public String getAcount_holder_name() {
		return Acount_holder_name;
	}
	public void setAcount_holder_name(String acount_holder_name) {
		Acount_holder_name = acount_holder_name;
	}
	public Double getAccount_balance() {
		return Account_balance;
	}
	public void setAccount_balance(Double account_balance) {
		Account_balance = account_balance;
	}
	@Override
	public String toString() {
		return "Account [Account_num=" + Account_num + ", Acount_holder_name=" + Acount_holder_name
				+ ", Account_balance=" + Account_balance + "]";
	}

	public Account get() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
